from setuptools import setup, find_packages

setup(
    name='mytestpackage',
    version='0.0.1',
    packages=find_packages(),
    description='A minimal test package for Azure Automation',
    author='Test Author',
    author_email='test@example.com',
    zip_safe=True
)
